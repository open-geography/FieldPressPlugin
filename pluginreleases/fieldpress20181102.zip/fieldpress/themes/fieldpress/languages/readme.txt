Translations for this theme are already handled in the translation file in the FieldPress plugin.
If you are experiencing difficulties with translations using the FieldPress theme, you can perform
additional translations here.


Visit the following links to learn more about translating WordPress themes:

http://codex.wordpress.org/Translating_WordPress
http://codex.wordpress.org/Function_Reference/load_theme_textdomain


