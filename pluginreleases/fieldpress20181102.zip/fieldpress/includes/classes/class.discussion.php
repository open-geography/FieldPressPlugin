<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'Discussion' ) ) {

	class Discussion {

		var $id = '';
		var $output = 'OBJECT';
		var $discussion = array();
		var $details;

		function __construct( $id = '', $output = 'OBJECT' ) {
			$this->id      = $id;
			$this->output  = $output;
			$this->details = get_post( $this->id, $this->output );
		}

		function Discussion( $id = '', $output = 'OBJECT' ) {
			$this->__construct( $id, $output );
		}

		function get_discussion() {

			$discussion = get_post( $this->id, $this->output );

			if ( ! empty( $discussion ) ) {
				return $discussion;
			} else {
				return new stdClass();
			}
		}

		function get_stop_name() {
			if ( ! isset( $this->details->stop_id ) || $this->details->stop_id == '' ) {
				return __( 'General', 'cp' );
			} else {
				$stop_obj = new Stop( $this->details->stop_id );
				$stop     = $stop_obj->get_stop();

				return $stop->post_title;
			}
		}

		function get_discussion_id_by_name( $slug ) {

			$args = array(
				'name'           => $slug,
				'post_type'      => 'discussion',
				'post_status'    => 'any',
				'posts_per_page' => 1
			);

			$post = get_posts( $args );

			if ( $post ) {
				return $post[0]->ID;
			} else {
				return false;
			}
		}

		function update_discussion( $discussion_title = '', $discussion_description = '', $field_id = '', $stop_id = '' ) {
			global $user_id, $wpdb;

			$discussion = get_post( $this->id, $this->output );

			$post_status = 'publish';

			$post = array(
				'post_author'  => $user_id,
				'post_content' => cp_filter_content( $discussion_description == '' ? $_POST['discussion_description'] : $discussion_description ),
				'post_status'  => $post_status,
				'post_title'   => cp_filter_content( ( $discussion_title == '' ? $_POST['discussion_name'] : $discussion_title ), true ),
				'post_type'    => 'discussions',
			);

			if ( isset( $_POST['discussion_id'] ) ) {
				$post['ID'] = $_POST['discussion_id']; //If ID is set, wp_insert_post will do the UPDATE instead of insert
			}

			$post_id = wp_insert_post( $post );

			//Update post meta
			if ( $post_id != 0 ) {

				if ( ! isset( $_POST['discussion_id'] ) ) {//new discussion added
					$instructors = Field::get_field_instructors_ids( $field_id );
					do_action( 'new_discussion_added_instructor_notification', $user_id, $field_id, $instructors );

					$students = Field::get_field_students_ids( $field_id );
					do_action( 'new_discussion_added_student_notification', $user_id, $field_id, $students );
				}

				if ( $stop_id == '' ) {
					$stop_id = $_POST['stops_dropdown'];
				}

				update_post_meta( $post_id, 'field_id', $field_id );
				update_post_meta( $post_id, 'stop_id', $stop_id );

				foreach ( $_POST as $key => $value ) {
					if ( preg_match( "/meta_/i", $key ) ) {//every field name with prefix "meta_" will be saved as post meta automatically
						update_post_meta( $post_id, str_replace( 'meta_', '', $key ), cp_filter_content( $value ) );
					}
				}
			}

			return $post_id;
		}

		function delete_discussion( $force_delete = true, $parent_field_id = false ) {
			$wpdb;
			if ( $parent_field_id ) {//delete all discussion with parent field id
				$args = array(
					'meta_key'   => 'field_id',
					'meta_value' => $parent_field_id,
					'post_type'  => 'discussions',
				);

				$discussions_to_delete = get_posts( $args );

				foreach ( $discussions_to_delete as $discussion_to_delete ) {
					if ( get_post_type( $discussion_to_delete->ID ) == 'discussions' ) {
						wp_delete_post( $discussion_to_delete->ID, $force_delete );
					}
				}
			} else {
				if ( get_post_type( $this->id ) == 'discussions' ) {
					wp_delete_post( $this->id, $force_delete ); //Whether to bypass trash and force deletion
				}
			}
		}

		function change_status( $post_status ) {
			$post = array(
				'ID'          => $this->id,
				'post_status' => $post_status,
			);

			// Update the post status
			wp_update_post( $post );
		}

	}

}
?>