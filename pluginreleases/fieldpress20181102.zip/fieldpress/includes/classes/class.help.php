<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>