<?php
global $fieldpress;

//$fieldpress->register_external_plugins();
if ( ! FieldPress_Capabilities::is_campus() ) {
//	$activation = new CP_Plugin_Activation();
//	$activation->install_plugins_page();
}